
import arss from "./js/arss.js"

arss.setup({})

